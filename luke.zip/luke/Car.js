module.exports = class Car{
	constructor(){
		this.pos = [0,0]
	}	
}
