node main 0 > ../output/a.out
node main 1 > ../output/b.out
node main 2 > ../output/c.out
node main 3 > ../output/d.out
node main 4 > ../output/e.out
